/** Automatically generated file. DO NOT MODIFY */
package com.example.accessibilitydemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}